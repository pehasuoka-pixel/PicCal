// camera page placeholder
